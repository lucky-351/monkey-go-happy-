var bananaImage, obstacleImage, obstacleGroup,foodGroup;
var monkey,ground,banana,monkey_running;
//Global Variables



function preload(){
  monkey_running = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_07.png","Monkey_09.png","Monkey_10.png");
  ground = loadImage("ground.jpg");
  bananaImage = loadImage("Banana.png");
  
}


function setup() {
  createCanvas(600,300);
  var background = createSprite("200,200,100,100");
  background = loadImage("jungle.png");
  background.x = background.width /2;
  background.velocityX = -4;
  
  var monkey = createSprite(100,380,20,50);
  monkey.addAnimation("monkey_running");
  monkey.scale = 0.5;
  
  
  var ground = createSprite(200,385,400,5);
  ground.x = ground.width /2;
  ground.velocityX = -4;
  
  
  foodGroup = new Group();
  obstaclesGroup = new Group();
  
  var score = 0;
}


function draw(){
   var score = score + Math.round(getFrameRate()/60);
  text("Score: "+ score, 500,50);
  
  if(keyDown("space")) {
    monkey.velocityY = -10;
  }
  
  monkey.velocityY =  monkey.velocityY + 0.8
  
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  
  monkey.collide(ground);
  spawnClouds();
  spawnObstacles();
  drawSprites();
}

function spawnfood() {
 
  if (frameCount % 60 === 0) {
    var bannana = createSprite(600,120,40,10);
    bannana.y = Math.round(random(80,120));
    bannana.addImage(Bannana.png);
    bannana.scale = 0.5;
    bannana.velocityX = -3;
    
     
   bannana.lifetime = 200;
    
    
   bannana.depth = trex.depth;
   monkey.depth = trex.depth + 1;
    
    
    foodGroup.add(bannana);
  }
  
}

function spawnObstacles() {
  if(frameCount % 60 === 0) {
    var obstacle = createSprite(600,165,10,40);
    obstacle.velocityX = -4;
    
    obstacle.addImage("stone.png");
    
           
    obstacle.scale = 0.5;
    obstacle.lifetime = 300;
    
    obstaclesGroup.add(obstacle);
  }


}